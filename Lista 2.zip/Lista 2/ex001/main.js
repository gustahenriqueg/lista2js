function calc() {
    var numero = document.getElementById("numero").value;
    var multiplicar = 1;
    document.getElementById("conteudo").innerHTML = "";
    while (multiplicar <= 10) {
        document.getElementById("conteudo").innerHTML += numero + "x" + multiplicar + "=" + (numero * multiplicar) + "<br />";
        multiplicar++;
    }
}